package com.neetpg.master

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private data class Mcq(val stem: String, val options: List<String>, val answer: Int, val explanation: String)

private val sampleQuestions = listOf(
    Mcq("Which immunoglobulin crosses the placenta most efficiently?", listOf("IgA", "IgG", "IgM", "IgE"), 1, "IgG is transported across the placenta through FcRn-mediated transport."),
    Mcq("The most common cause of bronchiolitis in infants is:", listOf("RSV", "Influenza B", "Streptococcus pneumoniae", "Mycoplasma"), 0, "Respiratory syncytial virus is the classic and most common cause of acute bronchiolitis.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeetPgApp() }
    }
}

@Composable
private fun NeetPgApp() {
    var screen by remember { mutableStateOf("Home") }
    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Practice", "Flashcards", "Notes").forEach { item ->
                        NavigationBarItem(selected = screen == item, onClick = { screen = item }, icon = {}, label = { Text(item) })
                    }
                }
            }
        ) { padding ->
            when (screen) {
                "Practice" -> PracticeScreen(Modifier.padding(padding))
                else -> HomeScreen(screen, Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun HomeScreen(screen: String, modifier: Modifier = Modifier) {
    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("NEET-PG Master", style = MaterialTheme.typography.headlineMedium)
        Text("Your structured medical revision workspace")
        Card { Column(Modifier.padding(16.dp)) { Text("Today's target", style = MaterialTheme.typography.titleMedium); Text("10 integrated MCQs + spaced revision") } }
        Text("Selected section: $screen")
        Text("Subjects", style = MaterialTheme.typography.titleLarge)
        listOf("Medicine", "Surgery", "Pediatrics", "Obstetrics & Gynaecology", "Microbiology", "Pharmacology").forEach { subject ->
            OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text(subject) }
        }
    }
}

@Composable
private fun PracticeScreen(modifier: Modifier = Modifier) {
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    val question = sampleQuestions[index]
    LazyColumn(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Practice MCQs", style = MaterialTheme.typography.headlineMedium); Text("Question ${index + 1} of ${sampleQuestions.size}") }
        item { Text(question.stem, style = MaterialTheme.typography.titleLarge) }
        items(question.options.indices.toList()) { optionIndex ->
            OutlinedButton(onClick = { selected = optionIndex }, modifier = Modifier.fillMaxWidth()) {
                Text("${'A' + optionIndex}. ${question.options[optionIndex]}")
            }
        }
        item {
            Button(onClick = {}, enabled = selected != null) { Text("Check answer") }
            if (selected != null) {
                Text(if (selected == question.answer) "Correct" else "Review the concept", style = MaterialTheme.typography.titleMedium)
                Text(question.explanation)
                Button(onClick = { index = (index + 1) % sampleQuestions.size; selected = null }) { Text("Next question") }
            }
        }
    }
}
