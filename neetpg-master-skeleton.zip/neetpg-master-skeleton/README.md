# NEET-PG Master — Full-Stack Skeleton

Starter architecture for a Kotlin Jetpack Compose Android app and a secure Firebase Functions backend.

## Modules
- `android/`: Kotlin + Jetpack Compose student app
- `backend/functions/`: server-side API boundary for admin/AI features
- `docs/`: architecture notes

## Run Android
Open `android/` in Android Studio, allow Gradle sync, and run on an emulator/device.

The starter uses local sample questions. Firebase integration is intentionally isolated for the next milestone.

## Security
Never put AI provider keys in the Android app. Add secrets only to server-side environment configuration.
