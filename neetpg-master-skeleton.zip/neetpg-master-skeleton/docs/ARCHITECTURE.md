# Architecture and security boundaries

## Roles
- student: read published questions, submit attempts, manage bookmarks
- admin: upload sources, generate drafts, edit, approve, publish

## Import lifecycle
1. Admin uploads a source.
2. Backend validates file type and size.
3. File is stored privately.
4. Extraction job produces normalized text.
5. AI creates draft MCQs.
6. Admin reviews every draft.
7. Only approved questions become published content.

## Recommended Firestore collections
- users
- subjects
- topics
- questions
- questionSources
- contentImports
- aiGenerationJobs
- userAttempts
- userBookmarks
- flashcardDecks
- flashcards
- pdfNotes

## Security requirements
- Firebase Authentication required for all private operations.
- Admin claims enforced server-side.
- Firestore rules deny client-side question publishing.
- AI provider secrets remain in server environment configuration.
- Validate and sanitize uploaded HTML and Anki media.
