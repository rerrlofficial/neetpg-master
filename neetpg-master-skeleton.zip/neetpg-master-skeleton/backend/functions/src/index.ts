import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";

initializeApp();

export const createMcqDraft = onCall({ region: "asia-south1" }, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign-in required.");
  const role = request.auth.token.admin === true;
  if (!role) throw new HttpsError("permission-denied", "Admin role required.");

  const sourceText = request.data?.sourceText;
  if (typeof sourceText !== "string" || sourceText.trim().length < 20) {
    throw new HttpsError("invalid-argument", "Valid source text is required.");
  }

  // Next milestone: call the AI provider here using server-side secrets.
  // Never expose provider credentials to the Android client.
  return {
    status: "draft_pending",
    message: "AI adapter boundary is ready; provider integration comes next.",
    sourceLength: sourceText.length
  };
});
